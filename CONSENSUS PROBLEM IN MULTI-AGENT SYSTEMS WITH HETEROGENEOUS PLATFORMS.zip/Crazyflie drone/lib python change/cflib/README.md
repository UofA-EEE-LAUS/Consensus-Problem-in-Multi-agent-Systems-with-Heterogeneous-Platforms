User guide 
Please copy and paste "position_hl_commander.py" to the "crazyflie-lib-python/cflib/positioning"

----------------------------

Our changes
'default_velocity' changes to 0.1 for a stabler flight.
'controller' changes to CONTROLLER_MELLINGER.