#ifndef STOP_AT_OBSTICLE_H
#define STOP_AT_OBSTICLE_H
void sequenceTask();
void sequenceInit();
bool sequenceTest();

#endif