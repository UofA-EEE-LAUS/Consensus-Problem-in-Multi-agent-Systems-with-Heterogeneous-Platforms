User Guide
1. Replace all the firmware change files into route "crazyflie-firmware/src/modules/src" for .c files 
   and "crazyflie-fimware/src/modules/interface" for .h files.
2. Build firmware in Eclipse IDE
3. Use CrazyRadio to flash the Crazyflie firmware
Check the Video for more details 


