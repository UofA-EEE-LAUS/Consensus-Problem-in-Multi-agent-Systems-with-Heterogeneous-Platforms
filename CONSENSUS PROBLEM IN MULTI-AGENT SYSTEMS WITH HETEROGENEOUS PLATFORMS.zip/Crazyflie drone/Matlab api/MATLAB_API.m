clc
clear
system ("python3 scan.py");
